import logo from './logo.svg';
import './App.css';
import Main from './components/Main';

function App() {
  return (
    <>
    <h1 className="rr" > API -Testing React APP </h1>
    <Main/>
    </>
  );
}

export default App;
