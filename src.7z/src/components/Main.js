import React ,{useEffect} from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';

const fetchData = () => {
     return axios.get("http://localhost:5000/tenant")
     .then((res)=>{
         console.log("coming in fetch");
         console.log(res)
     })
     .catch((err) =>{
         console.log(err)
     })
}
const Main = props => {
    useEffect(() => {
        fetchData()
      },[]);
    return (
        <div>
            <h1>I am from Main!</h1>
            <div class="button">
            <button>Tenent</button><button>Projects</button><button>Schedule</button>
            </div>
        </div>
    );
};

Main.propTypes = {
    
};

export default Main;