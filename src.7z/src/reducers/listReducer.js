const initialData = {
    list : []
}


const listReducer = (state = initialData, action)=>{
    switch(action.type){
        case 'ADD':
            const data = action.payload
            console.log("data in list reducer ",data.item);
            console.log("checking state ",state);
            // return { 
            //     ...state,
            //     list: [...state.list, {
            //         data:data.item
            //     }]
            // }
            return { 
                ...state,
                list: [...state.list,data.item]
            }
        case 'START':
            return state = {list:[]};
        default:
            return state;
    }
}

export default listReducer;